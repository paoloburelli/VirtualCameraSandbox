using System;
using UnityEngine;

namespace SandboxExtensions
{
	public static class AutonomousVehicleExtension
	{
		
		public static void Play (this AutonomousVehicle av)
		{
			av.enabled = true;
		}
		
		public static void Stop (this AutonomousVehicle av)
		{
			av.enabled = false;
			av.buffer = av.animation ["walk"].normalizedTime;
			av.animation ["walk"].enabled = false;
		}
		
		public static void Next (this AutonomousVehicle av)
		{
			av.enabled = false;
			av.FixedUpdate ();
			
			av.buffer += Time.fixedDeltaTime;
			av.animation ["walk"].normalizedTime = av.buffer;

			av.animation.Sample ();
			av.animation ["walk"].enabled = false;
		}
	}
}


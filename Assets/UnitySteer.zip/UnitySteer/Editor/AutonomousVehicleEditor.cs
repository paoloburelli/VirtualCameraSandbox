using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(AutonomousVehicle))]
public class AutonomousVehicleEditor: VehicleEditor {

}